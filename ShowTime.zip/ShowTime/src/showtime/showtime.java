package showtime;
import java.util.Calendar;
public class showtime {


	public static void main(String[] args) {
		System.out.println(Calendar.getInstance().getTime());

	}

}
